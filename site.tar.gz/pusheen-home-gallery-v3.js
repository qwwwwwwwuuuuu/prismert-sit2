(() => {
  const buildStorySection = (dataSection) => {
    const section = document.createElement("section");
    section.className = "pusheen-room-section pusheen-room-section--runner";
    section.dataset.pusheenStory = "true";
    section.setAttribute("aria-label", "PUSHIN market data");

    dataSection.className = "pusheen-story-copy";
    section.append(dataSection);

    const track = document.createElement("div");
    track.className = "pushin-cat-track";
    track.setAttribute("aria-hidden", "true");
    track.innerHTML = `
      <div class="pushin-running-cat">
        <svg class="pushin-running-cat__svg" viewBox="0 0 240 142" xmlns="http://www.w3.org/2000/svg" focusable="false">
          <g class="pushin-running-cat__body">
            <path class="pushin-running-cat__tail" d="M48 83C19 69 14 99 29 108C39 114 50 105 43 97"/>
            <ellipse cx="111" cy="76" rx="67" ry="43" fill="#b6aba1" stroke="#4b2f1d" stroke-width="6"/>
            <path d="M143 58L154 32L169 49C185 49 198 60 201 76C204 93 193 105 177 108L151 109C133 105 124 94 126 77C127 68 133 62 143 58Z" fill="#b6aba1" stroke="#4b2f1d" stroke-width="6" stroke-linejoin="round"/>
            <path d="M171 49L187 31L193 60" fill="#b6aba1" stroke="#4b2f1d" stroke-width="6" stroke-linejoin="round"/>
            <path d="M151 50L157 62M164 48L168 61M177 49L179 61" stroke="#7f756c" stroke-width="6" stroke-linecap="round"/>
            <circle cx="158" cy="76" r="4" fill="#4b2f1d"/>
            <circle cx="184" cy="76" r="4" fill="#4b2f1d"/>
            <path d="M169 82L173 86L177 82M173 86V91" fill="none" stroke="#4b2f1d" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M147 84L132 81M146 91L130 93M192 84L209 80M192 91L210 94" stroke="#4b2f1d" stroke-width="4" stroke-linecap="round"/>
            <path d="M72 50L78 61M86 43L90 58M101 41L104 56" stroke="#7f756c" stroke-width="7" stroke-linecap="round"/>
            <path d="M116 111C126 119 137 121 148 118" fill="none" stroke="#ee9ab2" stroke-width="7" stroke-linecap="round"/>
            <g class="pushin-running-cat__leg pushin-running-cat__leg--back">
              <path d="M82 105C70 118 65 126 50 127" fill="none" stroke="#4b2f1d" stroke-width="14" stroke-linecap="round"/>
              <path d="M82 105C70 117 66 123 51 124" fill="none" stroke="#b6aba1" stroke-width="7" stroke-linecap="round"/>
            </g>
            <g class="pushin-running-cat__leg pushin-running-cat__leg--front">
              <path d="M145 106C156 118 168 124 183 122" fill="none" stroke="#4b2f1d" stroke-width="14" stroke-linecap="round"/>
              <path d="M145 106C156 116 168 121 182 119" fill="none" stroke="#b6aba1" stroke-width="7" stroke-linecap="round"/>
            </g>
            <path d="M108 64C112 59 120 59 124 65C124 73 116 79 116 79C116 79 108 73 108 64Z" fill="#ef9db3"/>
          </g>
          <ellipse class="pushin-running-cat__shadow" cx="121" cy="132" rx="77" ry="7" fill="rgba(89,54,31,.13)"/>
        </svg>
      </div>
    `;
    section.append(track);
    return section;
  };

  const decorateRoomSections = (sections) => {
    const scenes = [
      [sections[2], "analysis"],
      [sections[3], "settlement"],
      [sections[4], "analysis"],
      [sections[5], "docs"],
      [sections[6], "settlement"],
      [sections[7], "docs"]
    ];

    scenes.forEach(([section, scene]) => {
      if (!section) return;
      section.classList.add("pusheen-room-section", `pusheen-room-section--${scene}`);
      section.dataset.roomScene = scene;
    });
  };

  const collapseEmptyMarket = (hero) => {
    const exactText = (value) => Array.from(hero.querySelectorAll("div, td"))
      .find((node) => node.children.length === 0 && node.textContent.trim() === value);

    const chartMessage = exactText("Preparing the chart");
    if (chartMessage) chartMessage.parentElement.hidden = true;

    const pricesMessage = exactText("No price observations yet");
    if (pricesMessage) {
      const table = pricesMessage.closest(".overflow-x-auto");
      if (table) table.hidden = true;
    }

    const fade = hero.querySelector(".pointer-events-none.absolute.inset-x-0.bottom-0");
    if (fade) fade.hidden = true;
  };

  const mount = () => {
    if (document.querySelector("[data-pusheen-story]")) return;

    const container = document.querySelector("main > div > div");
    if (!container) return;

    const sections = Array.from(container.children).filter((node) => node.tagName === "SECTION");
    if (sections.length < 5) return;

    const hero = sections[0];
    document.body.classList.add("pusheen-home");
    hero.classList.add("prism-hero");
    collapseEmptyMarket(hero);

    hero.after(buildStorySection(sections[1]));
    decorateRoomSections(sections);
  };

  window.addEventListener("load", () => {
    window.requestAnimationFrame(() => window.requestAnimationFrame(mount));
  }, { once: true });
})();
