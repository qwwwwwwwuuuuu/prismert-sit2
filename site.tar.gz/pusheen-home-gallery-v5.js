(() => {
  const createRunningCatTrack = () => {
    const track = document.createElement("div");
    track.className = "pushin-cat-track";
    track.setAttribute("aria-hidden", "true");
    track.innerHTML = `
      <div class="pushin-video-cat">
        <video class="pushin-video-cat__media" autoplay muted loop playsinline preload="auto">
          <source src="/brand/pushin-video-cat-alpha.webm" type="video/webm">
        </video>
      </div>
    `;
    return track;
  };

  const buildStorySection = (dataSection) => {
    const section = document.createElement("section");
    section.className = "pusheen-room-section pusheen-room-section--data";
    section.dataset.pusheenStory = "true";
    section.setAttribute("aria-label", "PUSHIN market data");

    dataSection.className = "pusheen-story-copy";
    section.append(dataSection);

    return section;
  };

  const mountMarketRunner = (container) => {
    const heading = Array.from(container.querySelectorAll("h2"))
      .find((node) => node.textContent.trim() === "The current state of both markets");
    const section = heading?.closest("section");
    if (!section) return;

    section.classList.remove(
      "pusheen-room-section--data",
      "pusheen-room-section--analysis",
      "pusheen-room-section--settlement",
      "pusheen-room-section--docs"
    );
    section.classList.add("pusheen-room-section", "pusheen-room-section--runner");
    section.removeAttribute("data-room-scene");
    section.dataset.pushinRunner = "true";

    if (!section.querySelector(".pushin-cat-track")) {
      section.append(createRunningCatTrack());
    }
  };

  const decorateRoomSections = (sections) => {
    const scenes = [
      [sections[2], "analysis"],
      [sections[3], "settlement"],
      [sections[4], "analysis"],
      [sections[5], "docs"],
      [sections[6], "settlement"],
      [sections[7], "docs"]
    ];

    scenes.forEach(([section, scene]) => {
      if (!section) return;
      section.classList.add("pusheen-room-section", `pusheen-room-section--${scene}`);
      section.dataset.roomScene = scene;
    });
  };

  const collapseEmptyMarket = (hero) => {
    const exactText = (value) => Array.from(hero.querySelectorAll("div, td"))
      .find((node) => node.children.length === 0 && node.textContent.trim() === value);

    const chartMessage = exactText("Preparing the chart");
    if (chartMessage) chartMessage.parentElement.hidden = true;

    const pricesMessage = exactText("No price observations yet");
    if (pricesMessage) {
      const table = pricesMessage.closest(".overflow-x-auto");
      if (table) table.hidden = true;
    }

    const fade = hero.querySelector(".pointer-events-none.absolute.inset-x-0.bottom-0");
    if (fade) fade.hidden = true;
  };

  const mount = () => {
    if (document.querySelector("[data-pusheen-story]")) return;

    const container = document.querySelector("main > div > div");
    if (!container) return;

    const sections = Array.from(container.children).filter((node) => node.tagName === "SECTION");
    if (sections.length < 5) return;

    const hero = sections[0];
    document.body.classList.add("pusheen-home");
    hero.classList.add("prism-hero");
    collapseEmptyMarket(hero);

    hero.after(buildStorySection(sections[1]));
    decorateRoomSections(sections);
    mountMarketRunner(container);
  };

  window.addEventListener("load", () => {
    window.requestAnimationFrame(() => window.requestAnimationFrame(mount));
  }, { once: true });
})();
