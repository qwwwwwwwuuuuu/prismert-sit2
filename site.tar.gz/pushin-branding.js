(function () {
  "use strict";

  var brandPattern = /PrismPerp/g;

  function replaceBrand(value) {
    return typeof value === "string" ? value.replace(brandPattern, "PUSHIN") : value;
  }

  function updateElement(element) {
    if (!element || element.nodeType !== Node.ELEMENT_NODE) return;
    ["aria-label", "title", "alt", "content"].forEach(function (name) {
      if (!element.hasAttribute(name)) return;
      var current = element.getAttribute(name);
      var next = replaceBrand(current);
      if (next !== current) element.setAttribute(name, next);
    });
  }

  function updateTree(root) {
    if (!root) return;
    if (root.nodeType === Node.TEXT_NODE) {
      var next = replaceBrand(root.nodeValue);
      if (next !== root.nodeValue) root.nodeValue = next;
      return;
    }
    updateElement(root);
    var walker = document.createTreeWalker(
      root,
      NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT
    );
    var node;
    while ((node = walker.nextNode())) {
      if (node.nodeType === Node.TEXT_NODE) {
        var text = replaceBrand(node.nodeValue);
        if (text !== node.nodeValue) node.nodeValue = text;
      } else {
        updateElement(node);
      }
    }
  }

  function applyBranding() {
    document.title = replaceBrand(document.title);
    updateTree(document.documentElement);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", applyBranding, { once: true });
  } else {
    applyBranding();
  }

  new MutationObserver(function (records) {
    records.forEach(function (record) {
      if (record.type === "characterData") updateTree(record.target);
      record.addedNodes.forEach(updateTree);
    });
  }).observe(document.documentElement, {
    childList: true,
    characterData: true,
    subtree: true
  });
})();
