(function () {
  "use strict";

  var nativeFetch = window.fetch ? window.fetch.bind(window) : null;
  var NativeEventSource = window.EventSource;

  function hash(text) {
    var value = 2166136261;
    for (var i = 0; i < text.length; i += 1) {
      value ^= text.charCodeAt(i);
      value = Math.imul(value, 16777619);
    }
    return value >>> 0;
  }

  function wave(seed, step, amplitude) {
    return (
      Math.sin((step + seed % 37) / 8.7) * amplitude +
      Math.sin((step + seed % 71) / 23.1) * amplitude * 0.42
    );
  }

  function currentValues() {
    var step = Date.now() / 3000;
    return {
      cvix: 45.82 + wave(11, step, 0.11),
      btc: 0.46 + wave(29, step, 0.026),
      eth: 0.21 + wave(47, step, 0.018)
    };
  }

  function marketState(market, value, open24h, oiLong, oiShort, borrowRate) {
    var spread = market === "CVIX30" ? 0.72 : 0.17;
    return {
      market: market,
      open24h: open24h,
      high24h: Math.max(value, open24h) + spread,
      low24h: Math.min(value, open24h) - spread * 0.82,
      oiLong: oiLong,
      oiShort: oiShort,
      borrowRate: borrowRate,
      notional24h: (oiLong + oiShort) * 3.17,
      status: "live"
    };
  }

  function makeSnapshot() {
    var values = currentValues();
    return {
      live: true,
      at: Date.now(),
      feed: { fresh: true, ageMs: 0 },
      index: { value: values.cvix, dampened: false },
      basis: {
        BTC: { spread: values.btc },
        ETH: { spread: values.eth }
      },
      markets: [
        marketState("CVIX30", values.cvix, 46.04, 15900000, 10100000, 0.00442),
        marketState("FRBASIS-BTC", values.btc, 0.43, 9100000, 8400000, 0.00241),
        marketState("FRBASIS-ETH", values.eth, 0.19, 6800000, 6200000, 0.00184)
      ],
      sources: {
        index: "modelled",
        basis: "modelled",
        book: "simulated",
        vault: "simulated"
      },
      oracles: [
        { name: "Deribit BTC", ok: true },
        { name: "Deribit ETH", ok: true },
        { name: "Binance BTC", ok: true },
        { name: "Binance ETH", ok: true },
        { name: "Hyperliquid BTC", ok: true },
        { name: "Hyperliquid ETH", ok: true },
        { name: "Robinhood Chain", ok: true }
      ],
      venue: {
        mode: "paper",
        network: "mainnet",
        chainId: 4663,
        accepts: ["USDG", "ETH"]
      },
      resting: {},
      fills: []
    };
  }

  function candlePrice(market, timestamp) {
    var seed = hash(market);
    var step = timestamp / 60;
    if (market === "CVIX30") return 45.82 + wave(seed, step, 0.72);
    if (market === "FRBASIS-BTC") return 0.46 + wave(seed, step, 0.14);
    return 0.21 + wave(seed, step, 0.1);
  }

  function makeCandles(market, interval, limit) {
    var now = Math.floor(Date.now() / 1000);
    var count = Math.max(80, Math.min(Number(limit) || 500, 500));
    var step = Math.max(60, Number(interval) || 60);
    var candles = [];
    for (var i = count - 1; i >= 0; i -= 1) {
      var time = now - i * step;
      var open = candlePrice(market, time - step);
      var close = candlePrice(market, time);
      var wiggle = Math.max(Math.abs(close - open) * 0.55, market === "CVIX30" ? 0.025 : 0.004);
      candles.push({
        time: time,
        open: open,
        high: Math.max(open, close) + wiggle,
        low: Math.min(open, close) - wiggle,
        close: close,
        volume: 18000 + ((hash(market + ":" + time) % 76000) + i * 31) % 76000
      });
    }
    return { ok: true, candles: candles, coverage: { source: "modelled", complete: true } };
  }

  function jsonResponse(payload) {
    return new Response(JSON.stringify(payload), {
      status: 200,
      headers: { "content-type": "application/json", "cache-control": "no-store" }
    });
  }

  if (nativeFetch) {
    window.fetch = function (input, init) {
      var url = typeof input === "string" ? input : input && input.url ? input.url : "";
      var parsed;
      try {
        parsed = new URL(url, window.location.href);
      } catch (_) {
        return nativeFetch(input, init);
      }
      if (parsed.origin === window.location.origin && parsed.pathname === "/api/snapshot") {
        return Promise.resolve(jsonResponse(makeSnapshot()));
      }
      if (parsed.origin === window.location.origin && parsed.pathname === "/api/candles") {
        return Promise.resolve(
          jsonResponse(
            makeCandles(
              parsed.searchParams.get("market") || "CVIX30",
              parsed.searchParams.get("interval") || 60,
              parsed.searchParams.get("limit") || 500
            )
          )
        );
      }
      if (parsed.origin === window.location.origin && parsed.pathname === "/api/history") {
        return Promise.resolve(jsonResponse({ ok: true, points: [], history: [] }));
      }
      return nativeFetch(input, init);
    };
  }

  function LocalEventSource() {
    var self = this;
    self.readyState = 0;
    self.url = "/api/stream";
    self.withCredentials = false;
    self._timer = null;
    setTimeout(function () {
      self.readyState = 1;
      if (typeof self.onopen === "function") self.onopen({ type: "open" });
      self._emit();
      self._timer = setInterval(function () { self._emit(); }, 3000);
    }, 80);
  }

  LocalEventSource.prototype._emit = function () {
    if (this.readyState !== 1 || typeof this.onmessage !== "function") return;
    this.onmessage({ type: "message", data: JSON.stringify(makeSnapshot()) });
  };
  LocalEventSource.prototype.close = function () {
    this.readyState = 2;
    if (this._timer) clearInterval(this._timer);
  };
  LocalEventSource.CONNECTING = 0;
  LocalEventSource.OPEN = 1;
  LocalEventSource.CLOSED = 2;

  if (NativeEventSource) {
    window.EventSource = function (url, options) {
      var parsed = new URL(String(url), window.location.href);
      if (parsed.origin === window.location.origin && parsed.pathname === "/api/stream") {
        return new LocalEventSource();
      }
      return new NativeEventSource(url, options);
    };
    window.EventSource.CONNECTING = 0;
    window.EventSource.OPEN = 1;
    window.EventSource.CLOSED = 2;
  }
})();
